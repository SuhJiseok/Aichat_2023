import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';

function FriendProfile() {
/*   const [name, setName] = useState('');
  const [image, setImage] = useState(''); */
  // console.log('props---------', props)
  // props.location.state가 존재하는 경우에만 name과 image 값을 업데이트
/*   if (props.location.state) {
    setName(props.location.state.name);
    setImage(props.location.state.image);
  } */
const {friendname, friendimage} = useLocation().state
console.log(useState().state)
  return (
    <div>
      <h1>{friendname}</h1>
      <img src={friendimage} alt={friendname} />
    </div>
  );
}

export default FriendProfile;
